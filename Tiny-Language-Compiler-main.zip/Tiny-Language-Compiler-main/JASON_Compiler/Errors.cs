﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JASON_Compiler
{
    public static class Errors
    {
       public static List<string> Error_List = new List<string>();
    }
}
