# Tiny-Language-Compiler
a simple compiler for compiling Tiny Language using regular expressions, DFA, NFA and CFG.
